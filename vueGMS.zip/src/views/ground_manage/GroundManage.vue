<template>
  <div>
    这里是冯炳添广场
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>