<template>
  <div>
    这是黎伯华广场
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>